package com.estacionamento.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEstacionamentoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiEstacionamentoApplication.class, args);
    }
}
